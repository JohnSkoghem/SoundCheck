﻿#---------------------------------------------------------[Initialisations]--------------------------------------------------------
# Designed by    Ivan.Dumnov@packaging-systems.ru     2024

# Init PowerShell Gui
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
add-type -typeDefinition '

using System;
using System.Runtime.InteropServices;

public class Shell32_Extract {

  [DllImport(
     "Shell32.dll",
      EntryPoint        = "ExtractIconExW",
      CharSet           =  CharSet.Unicode,
      ExactSpelling     =  true,
      CallingConvention =  CallingConvention.StdCall)
  ]

   public static extern int ExtractIconEx(
      string lpszFile          , // Name of the .exe or .dll that contains the icon
      int    iconIndex         , // zero based index of first icon to extract. If iconIndex == 0 and and phiconSmall == null and phiconSmall = null, the number of icons is returnd
      out    IntPtr phiconLarge,
      out    IntPtr phiconSmall,
      int    nIcons
  );

}
';

Function ICO_Extractor{
    param (
        $iconIndex
    )
    
    $iconPath                    = "C:\Program Files\PS_Tools\SoundCheck\AudioDeviceCmdlets\Release\AudioDeviceCmdlets.dll"
    #$iconPath                   = "C:\Windows\system32\mmres.dll"
    [System.IntPtr] $phiconSmall = 1
    [System.IntPtr] $phiconLarge = 0

    $nofImages = [Shell32_Extract]::ExtractIconEx($iconPath, $iconIndex, [ref] $phiconLarge, [ref] $phiconSmall, 1)

    #$icon = [System.Drawing.Icon]::FromHandle($phiconSmall);
    #$icon = [System.Drawing.Icon]::FromHandle($phiconLarge);

    return [System.Drawing.Icon]::FromHandle($phiconLarge);
}

#---------------------------------------------------------[Form]--------------------------------------------------------

[System.Windows.Forms.Application]::EnableVisualStyles()

# Create a new form
$ITMultiToolForm = New-Object system.Windows.Forms.Form

# Define the size, title and background color
$ITMultiToolForm.ClientSize      = '470,455'
$ITMultiToolForm.AutoSize        = $true
$ITMultiToolForm.text            = "Аудиоустройства"
$ITMultiToolForm.BackColor       = "#F1F1F1"
$ITMultiToolForm.Icon            = ICO_Extractor (0)

# Create a Title for our form. We will use a label for it.
$Description                     = New-Object system.Windows.Forms.GroupBox
$Description.text                = "Диагностика и настройка устройств по умолчанию:"
$Description.width               = 470
$Description.height              = 320
$Description.location            = New-Object System.Drawing.Point(2,10)
$Description.Font                = 'Microsoft Sans Serif,10'
$Description.ForeColor           = "#0032B1"

#Icons of devices
$HeadSetIco                      = New-Object system.Windows.Forms.PictureBox
$HeadSetIco.width                = 50
$HeadSetIco.height               = 50
$HeadSetIco.location             = New-Object System.Drawing.Point(60,50)
$HeadSetIco.imageLocation        = "C:\Program Files\PS_Tools\SoundCheck\AudioDeviceCmdlets\icons\1.ico"
$HeadSetIco.SizeMode             = [System.Windows.Forms.PictureBoxSizeMode]::zoom

$MicrophoneIco                   = New-Object system.Windows.Forms.PictureBox
$MicrophoneIco.width             = 50
$MicrophoneIco.height            = 50
$MicrophoneIco.imageLocation     = "C:\Program Files\PS_Tools\SoundCheck\AudioDeviceCmdlets\icons\2.ico"
$MicrophoneIco.SizeMode          = [System.Windows.Forms.PictureBoxSizeMode]::zoom

$DinamicIco                      = New-Object system.Windows.Forms.PictureBox
$DinamicIco.width                = 50
$DinamicIco.height               = 50
$DinamicIco.imageLocation        = "C:\Program Files\PS_Tools\SoundCheck\AudioDeviceCmdlets\icons\3.ico"
$DinamicIco.SizeMode             = [System.Windows.Forms.PictureBoxSizeMode]::zoom

$HeadSetName                     = New-Object system.Windows.Forms.Label
$HeadSetName.AutoSize            = $true
$HeadSetName.location            = New-Object System.Drawing.Point(45,120)
$HeadSetName.Font                = 'Microsoft Sans Serif,10'
$HeadSetName.ForeColor           = "#0032B1"

$HeadSetNameMic                  = New-Object system.Windows.Forms.Label
$HeadSetName.AutoSize            = $true
$HeadSetNameMic.location         = New-Object System.Drawing.Point(45,138)
$HeadSetNameMic.Font             = 'Microsoft Sans Serif,10'
$HeadSetNameMic.ForeColor        = "#0032B1"

$MicrophoneName                  = New-Object system.Windows.Forms.Label
$MicrophoneName.AutoSize         = $true
$MicrophoneName.Font             = 'Microsoft Sans Serif,10'
$MicrophoneName.ForeColor        = "#0032B1"

$DinamicName                     = New-Object system.Windows.Forms.Label
$DinamicName.AutoSize            = $true
$DinamicName.Font                = 'Microsoft Sans Serif,10'
$DinamicName.ForeColor           = "#0032B1"

# Devices current statement
$HeadSetLabel1                   = New-Object system.Windows.Forms.Label
$HeadSetLabel1.text              = "Гарнитура:"
$HeadSetLabel1.AutoSize          = $true
$HeadSetLabel1.location          = New-Object System.Drawing.Point(20,180)
$HeadSetLabel1.Font              = 'Microsoft Sans Serif,10,style=Bold'
$HeadSetLabel1.ForeColor         = "#0032B1"

$MicrophoneLabel1                = New-Object system.Windows.Forms.Label
$MicrophoneLabel1.text           = "Микрофон:"
$MicrophoneLabel1.AutoSize       = $true
$MicrophoneLabel1.Font           = 'Microsoft Sans Serif,10,style=Bold'
$MicrophoneLabel1.ForeColor      = "#0032B1"

$DinamicLabel1                   = New-Object system.Windows.Forms.Label
$DinamicLabel1.text              = "Динамик:"
$DinamicLabel1.AutoSize          = $true
$DinamicLabel1.Font              = 'Microsoft Sans Serif,10,style=Bold'
$DinamicLabel1.ForeColor         = "#0032B1"

$HeadSetStatment                 = New-Object system.Windows.Forms.Label
$HeadSetStatment.AutoSize        = $true
$HeadSetStatment.location        = New-Object System.Drawing.Point(100,180)
$HeadSetStatment.Font            = 'Microsoft Sans Serif,10'
$HeadSetStatment.ForeColor       = "#0032B1"

$MicrophoneStatment              = New-Object system.Windows.Forms.Label
$MicrophoneStatment.AutoSize     = $true

$MicrophoneStatment.Font         = 'Microsoft Sans Serif,10'
$MicrophoneStatment.ForeColor    = "#0032B1"

$DinamicStatment                 = New-Object system.Windows.Forms.Label
$DinamicStatment.AutoSize        = $true
$DinamicStatment.Font            = 'Microsoft Sans Serif,10'
$DinamicStatment.ForeColor       = "#0032B1"

#Icons for status
$HeadSetStatusIco                = New-Object system.Windows.Forms.PictureBox
$HeadSetStatusIco.width          = 20
$HeadSetStatusIco.height         = 20
$HeadSetStatusIco.location       = New-Object System.Drawing.Point(90,99)
$HeadSetStatusIco.SizeMode       = [System.Windows.Forms.PictureBoxSizeMode]::zoom

$MicrophoneStatusIco             = New-Object system.Windows.Forms.PictureBox
$MicrophoneStatusIco.width       = 20
$MicrophoneStatusIco.height      = 20
$MicrophoneStatusIco.SizeMode    = [System.Windows.Forms.PictureBoxSizeMode]::zoom

$DinamicStatusIco                = New-Object system.Windows.Forms.PictureBox
$DinamicStatusIco.width          = 20
$DinamicStatusIco.height         = 20
$DinamicStatusIco.SizeMode       = [System.Windows.Forms.PictureBoxSizeMode]::zoom

# Devices adjustment menu

$NewSettings                     = New-Object system.Windows.Forms.GroupBox
$NewSettings.text                = "Новые параметры:"
$NewSettings.width               = 470
$NewSettings.Font                = 'Microsoft Sans Serif,10'
$NewSettings.ForeColor           = "#0032B1"

$HeadSetLabel2                   = New-Object system.Windows.Forms.Label
$HeadSetLabel2.text              = "Гарнитура:"
$HeadSetLabel2.AutoSize          = $true
$HeadSetLabel2.location          = New-Object System.Drawing.Point(20,350)
$HeadSetLabel2.Font              = 'Microsoft Sans Serif,10,style=Bold'
$HeadSetLabel2.ForeColor         = "#929292"

$MicrophoneLabel2                = New-Object system.Windows.Forms.Label
$MicrophoneLabel2.text           = "Микрофон:"
$MicrophoneLabel2.AutoSize       = $true
$MicrophoneLabel2.Font           = 'Microsoft Sans Serif,10,style=Bold'
$MicrophoneLabel2.ForeColor      = "#929292"

$DinamicLabel2                   = New-Object system.Windows.Forms.Label
$DinamicLabel2.text              = "Динамик:"
$DinamicLabel2.AutoSize          = $true
$DinamicLabel2.Font              = 'Microsoft Sans Serif,10,style=Bold'
$DinamicLabel2.ForeColor         = "#929292"

$HeadSetVolume                   = New-Object System.Windows.Forms.TrackBar
$HeadSetVolume.location          = New-Object System.Drawing.Point(100,350)
$HeadSetVolume.Minimum           = 0
$HeadSetVolume.Maximum           = 99
$HeadSetVolume.TickFrequency     = 3
$HeadSetVolume.Font              = 'Microsoft Sans Serif,10'

$MicrophoneVolume                = New-Object System.Windows.Forms.TrackBar
$MicrophoneVolume.Minimum        = 0
$MicrophoneVolume.Maximum        = 99
$MicrophoneVolume.TickFrequency  = 3
$MicrophoneVolume.Font           = 'Microsoft Sans Serif,10'

$DinamicVolume                   = New-Object System.Windows.Forms.TrackBar
$DinamicVolume.Minimum           = 0
$DinamicVolume.Maximum           = 99
$DinamicVolume.TickFrequency     = 3
$DinamicVolume.Font              = 'Microsoft Sans Serif,10'

$HeadSetCheckBox                 = New-Object System.Windows.Forms.checkBox
$HeadSetCheckBox.location        = New-Object System.Drawing.Point(220,350)
$HeadSetCheckBox.Font            = 'Microsoft Sans Serif,10'
$HeadSetCheckBox.ForeColor       = "#0032B1"
$HeadSetCheckBox.Visible         = $false

$MicrophoneCheckBox              = New-Object System.Windows.Forms.checkBox
$MicrophoneCheckBox.Font         = 'Microsoft Sans Serif,10'
$MicrophoneCheckBox.ForeColor    = "#0032B1"
$MicrophoneCheckBox.Visible      = $false

$DinamicCheckBox                 = New-Object System.Windows.Forms.checkBox
$DinamicCheckBox.Font            = 'Microsoft Sans Serif,10'
$DinamicCheckBox.ForeColor       = "#0032B1"
$DinamicCheckBox.Visible         = $false

#Buttons

$cancelBtn                       = New-Object system.Windows.Forms.Button
$cancelBtn.BackColor             = "#ffffff"
$cancelBtn.text                  = "Закрыть"
$cancelBtn.width                 = 100
$cancelBtn.height                = 30
$cancelBtn.Font                  = 'Microsoft Sans Serif,10'
$cancelBtn.ForeColor             = "#000"
$cancelBtn.DialogResult          = [System.Windows.Forms.DialogResult]::Cancel
$ITMultiToolForm.CancelButton    = $cancelBtn
$ITMultiToolForm.Controls.Add($cancelBtn)

$TroubleshootingBtn              = New-Object system.Windows.Forms.Button
$TroubleshootingBtn.width        = 120
$TroubleshootingBtn.height       = 30

$HeadSetBtn                      = New-Object system.Windows.Forms.Button
$HeadSetBtn.location             = New-Object System.Drawing.Point(220,350)
$HeadSetBtn.width                = 100
$HeadSetBtn.height               = 30
$HeadSetBtn.Visible              = $true

$MicrophoneBtn                   = New-Object system.Windows.Forms.Button
$MicrophoneBtn.width             = 100
$MicrophoneBtn.height            = 30
$MicrophoneBtn.Visible           = $true

$DinamicBtn                      = New-Object system.Windows.Forms.Button
$DinamicBtn.width                = 100
$DinamicBtn.height               = 30
$DinamicBtn.Visible              = $true

# Other elemtents
$Logo_ICO                        = New-Object system.Windows.Forms.PictureBox
$Logo_ICO.width                  = 100
$Logo_ICO.height                 = 50
$Logo_ICO.imageLocation          = "C:\Program Files\PS_Tools\OutlookSignature\Logo_Rus.png"
$Logo_ICO.SizeMode               = [System.Windows.Forms.PictureBoxSizeMode]::zoom

$Scale_ICO                       = New-Object system.Windows.Forms.PictureBox
$Scale_ICO.width                 = 90
$Scale_ICO.height                = 25
$Scale_ICO.imageLocation         = "C:\Program Files\PS_Tools\SoundCheck\AudioDeviceCmdlets\icons\Scale.png"
$Scale_ICO.SizeMode              = [System.Windows.Forms.PictureBoxSizeMode]::zoom

$Level_Label                     = New-Object system.Windows.Forms.Label
$Level_Label.text                = "-    Уровень    +"
$Level_Label.AutoSize            = $true
$Level_Label.Font                = 'Microsoft Sans Serif,10'
$Level_Label.ForeColor           = "#929292"

$Version                         = New-Object system.Windows.Forms.Label
$Version.Text                    = "v4.12"
$Version.AutoSize                = $true
$Version.Font                    = 'Microsoft Sans Serif,10'
$Version.ForeColor               = "#EAEAEA"

# Add the elements to the form
$ITMultiToolForm.controls.AddRange(@($HeadSetIco,$MicrophoneIco,$DinamicIco,$Logo_ICO,$Level_Label,$HeadSetStatusIco,$MicrophoneStatusIco,$DinamicStatusIco,  `
    $HeadSetName,$HeadSetNameMic,$MicrophoneName,$DinamicName,$HeadSetLabel1,$DinamicLabel1,$MicrophoneLabel1,$HeadSetLabel2,$DinamicLabel2,$MicrophoneLabel2,  `
    $HeadSetStatment,$MicrophoneStatment,$DinamicStatment,$cancelBtn,$TroubleshootingBtn,$HeadSetBtn,$MicrophoneBtn,$DinamicBtn,$Version,$HeadSetVolume,$MicrophoneVolume,$DinamicVolume,$Scale_ICO,  `
    $HeadSetCheckBox,$MicrophoneCheckBox,$DinamicCheckBox,$NewSettings,$Description))


#-----------------------------------------------------------[Functions]-----------------------------------------------------------#
function Error_General {
    $MicrophoneStatment.text    = "Критическая ошибка"
    $MicrophoneStatment.text    = $StatusStatment.text + "`n`nВо время работы приложения произошла ошибка."
    #$StatusStatment.text       = $StatusStatment.text + "`nException type is $($_.Exception.GetType().Name) `n$Error"
    $MicrophoneStatment.text    = $StatusStatment.text + "`n`nДля обращения в поддержку IT используйте:"
    $MicrophoneStatment.text    = $StatusStatment.text + "`n     Портал: https://service.packaging-systems.ru"
    $MicrophoneStatment.text    = $StatusStatment.text + "`n     Jabber: 7012010"
    $MicrophoneStatment.text    = $StatusStatment.text + "`n     Городской номер: +74957878080`n"
    $TroubleshootingBtn.Visible = $false
}

Function Remove-RoutedEventHandlers {
    [CmdletBinding()]
    Param (
        [Parameter(Mandatory    = $True)]
        [ValidateNotNullorEmpty()]
        [System.Windows.UIElement]$Element,
        [Parameter(Mandatory    = $True)]
        [ValidateNotNullorEmpty()]
        [System.Windows.RoutedEvent]$RoutedEvent
    )
    
    $eventHandlersStoreProperty = $Element.GetType().GetProperty("EventHandlersStore", [System.Reflection.BindingFlags]'Instance, NonPublic')
    $eventHandlersStore = $eventHandlersStoreProperty.GetValue($Element, $Null)
    If ($eventHandlersStore) {
        $getRoutedEventHandlers = $eventHandlersStore.GetType().GetMethod("GetRoutedEventHandlers", [System.Reflection.BindingFlags]'Instance, Public, NonPublic')
        $RoutedEventHandlers = [System.Windows.RoutedEventHandlerInfo[]]$getRoutedEventHandlers.Invoke($eventHandlersStore, $RoutedEvent)
        ForEach ($RoutedEventHandler in $RoutedEventHandlers) {
            $Element.RemoveHandler($RoutedEvent, $RoutedEventHandler.Handler)
        }
    }
}

function RandomBacklight {` 
    $random = New-Object System.Random 
    switch ($random.Next(9)) { 
        0 {$ITMultiToolForm.BackColor = "LightBlue"} 
        1 {$ITMultiToolForm.BackColor = "LightGreen"} 
        2 {$ITMultiToolForm.BackColor = "LightPink"} 
        3 {$ITMultiToolForm.BackColor = "Yellow"} 
        4 {$ITMultiToolForm.BackColor = "Orange"} 
        5 {$ITMultiToolForm.BackColor = "Brown"} 
        6 {$ITMultiToolForm.BackColor = "Magenta"} 
        7 {$ITMultiToolForm.BackColor = "White"} 
        8 {$ITMultiToolForm.BackColor = "Gray"} 
    } 
}

function Main_Window {
    $TroubleshootingBtn.Add_Click({ Troubleshooting })
    $HeadSetBtn.Add_Click({ 
        $HeadSetVolumeSet                       = $HeadSetVolume.Value
        $RecordingVolumeSet                     = $MicrophoneVolume.Value
        $PlaybackVolumeSet                      = $DinamicVolume.Value
        $HeadSetBtn.Visible                     = $false
        Troubleshooting_HeadSet ($false) 
    }) 
    $MicrophoneBtn.Add_Click({ 
        $HeadSetVolumeSet                       = $HeadSetVolume.Value
        $RecordingVolumeSet                     = $MicrophoneVolume.Value
        $PlaybackVolumeSet                      = $DinamicVolume.Value
        $MicrophoneBtn.Visible                  = $false
        Troubleshooting_Microphone ($false) 
    }) 
    $DinamicBtn.Add_Click({ 
        $HeadSetVolumeSet                       = $HeadSetVolume.Value
        $RecordingVolumeSet                     = $MicrophoneVolume.Value
        $PlaybackVolumeSet                      = $DinamicVolume.Value
        $DinamicBtn.Visible                     = $false
        Troubleshooting_Dinamic 
    }) 
     
    $HeadSetVolume.Add_Click({ 
        $HeadSetCheckBox.Checked    = $True
        $HeadSetBtn.Visible         = $true
        Colour_If_CheckBox 
    }) 
    $MicrophoneVolume.Add_Click({ 
        $MicrophoneCheckBox.Checked = $True
        $MicrophoneBtn.Visible      = $true
        Colour_If_CheckBox
    }) 
    $DinamicVolume.Add_Click({ 
        $DinamicCheckBox.Checked    = $True 
        $DinamicBtn.Visible         = $true
        Colour_If_CheckBox
    })  
    $ITMultiToolForm.Add_DoubleClick({ RandomBacklight })
    $HeadSetCheckBox.Add_Click({Colour_If_CheckBox}) 
    $MicrophoneCheckBox.Add_Click({Colour_If_CheckBox}) 
    $DinamicCheckBox.Add_Click({Colour_If_CheckBox}) 
    
    $TroubleshootingBtn.BackColor   = "#ffffff"
    $TroubleshootingBtn.text        = "Настроить все"
    $TroubleshootingBtn.Font        = 'Microsoft Sans Serif,10'
    $TroubleshootingBtn.ForeColor   = "#000"
    $TroubleshootingBtn.Visible     = $true

    $HeadSetBtn.BackColor           = "#ffffff"
    $HeadSetBtn.text                = "Применить"
    $HeadSetBtn.Font                = 'Microsoft Sans Serif,10'
    $HeadSetBtn.ForeColor           = "#000"
    $HeadSetBtn.Visible             = $false

    $MicrophoneBtn.BackColor        = "#ffffff"
    $MicrophoneBtn.text             = "Применить"
    $MicrophoneBtn.Font             = 'Microsoft Sans Serif,10'
    $MicrophoneBtn.ForeColor        = "#000"
    $MicrophoneBtn.Visible          = $false

    $DinamicBtn.BackColor           = "#ffffff"
    $DinamicBtn.text                = "Применить"
    $DinamicBtn.Font                = 'Microsoft Sans Serif,10'
    $DinamicBtn.ForeColor           = "#000"
    $DinamicBtn.Visible             = $false
    
    Devices_Status
}

function DevicesName{
  #Get Device name
  Param($Data)
  $Data | Select-Object Name | Out-String | %{$_.split('(')[1]} | % {$_.replace(")","")} | % {$_.replace(")","")} | % {$_.replace("`n","")} | % {$_.Substring(0, [Math]::Min($_.Length, 21))}
}

Function Colour_If_CheckBox {
    If ($HeadSetCheckBox.Checked -eq $true){
        $HeadSetLabel2.ForeColor         = "#0032B1"
        $HeadSetVolume.ForeColor         = "#0032B1"
    }else{
        $HeadSetLabel2.ForeColor         = "#929292"
        $HeadSetVolume.ForeColor         = "#929292"
    }
    
    If ($MicrophoneCheckBox.Checked -eq $true){
        $MicrophoneLabel2.ForeColor      = "#0032B1"
        $MicrophoneVolume.ForeColor      = "#0032B1"
    }else{
        $MicrophoneLabel2.ForeColor      = "#929292"
        $MicrophoneVolume.ForeColor      = "#929292"
    }

    If ($DinamicCheckBox.Checked -eq $true){
        $DinamicLabel2.ForeColor         = "#0032B1"
        $DinamicVolume.ForeColor         = "#0032B1"
    }else{
        $DinamicLabel2.ForeColor         = "#929292"
        $DinamicVolume.ForeColor         = "#929292"
    }
}

function Devices_Status {
    #Check Headset
    $HeadSetStatment.text                = ""
    $HeadSetCheckBox.Checked             = $True
    $HeadSetVolume.Value                 = $HeadSetVolumeSet
    $HeadSetStatusIco.BringToFront()
    $HeadSetName.text                    = DevicesName (Get-AudioDevice -PlaybackCommunication)
    #$HeadSetName.text                   = $HeadSetName.text + "+"
    $HeadSetNameMic.text                 = DevicesName (Get-AudioDevice -RecordingCommunication)
    #$HeadSetNameMic.text                = $HeadSetNameMic.text + "+"

    if (((Get-AudioDevice -RecordingCommunicationMute) -eq $true) -or ((Get-AudioDevice -PlaybackCommunicationMute) -eq $true )) {
        $HeadSetStatment.text            = $HeadSetStatment.text + "Гарнитура отключена`n"
        $HeadSetStatusIco.image          = ICO_Extractor (6)
        $HeadSetBtn.Visible              = $true
    } elseif (((Get-AudioDevice -RecordingCommunicationVolume) -lt 60) -or ((Get-AudioDevice -PlaybackCommunicationVolume) -lt 50)) {
        $HeadSetStatment.text            = $HeadSetStatment.text + "Чувствительность гарнитуры снижена"
        $HeadSetStatusIco.image          = ICO_Extractor (5)
        $HeadSetBtn.Visible              = $true
    } else {
        $HeadSetStatment.text            = "Готов к работе"
        $HeadSetCheckBox.Checked         = $false
        $HeadSetBtn.Visible              = $false
        $HeadSetStatusIco.image          = ICO_Extractor (4)
    }

    #Check Microphone
    $MicrophoneStatment.text             = ""
    $MicrophoneCheckBox.Checked          = $true
    $MicrophoneVolume.Value              = $RecordingVolumeSet
    $MicrophoneVolume.BringToFront()
    $MicrophoneStatusIco.BringToFront()
    $MicrophoneName.text                 = DevicesName (Get-AudioDevice -Recording)
    
    if ((DevicesName (Get-AudioDevice -Recording)).Length -ge 20){
        $MicrophoneName.location         = New-Object System.Drawing.Point(180,120)
    }

    if ((Get-AudioDevice -RecordingMute) -eq $true ) {
        $MicrophoneStatment.text         = $MicrophoneStatment.text + "Микрофон отключен`n"
        $MicrophoneStatusIco.image       = ICO_Extractor (6)
        $MicrophoneBtn.Visible           = $true
    } elseif ((Get-AudioDevice -RecordingVolume) -lt 60) {
        $MicrophoneStatment.text         = $MicrophoneStatment.text + "Чувствительность микрофона снижена"
        $MicrophoneStatusIco.image       = ICO_Extractor (5)
        $MicrophoneBtn.Visible           = $true
    } else {
        $MicrophoneStatment.text         = "Готов к работе"
        $MicrophoneCheckBox.Checked      = $false
        $MicrophoneBtn.Visible           = $false
        $MicrophoneStatusIco.image       = ICO_Extractor (4)
    }


    #Check Speaker
    $DinamicStatment.text                = ""
    $DinamicCheckBox.Checked             = $true
    $DinamicVolume.Value                 = $PlaybackVolumeSet
    $DinamicVolume.BringToFront()
    $DinamicStatusIco.BringToFront()
    $DinamicName.text                    = DevicesName (Get-AudioDevice -Playback)

    if ((Get-AudioDevice -PlaybackMute) -eq $true ) {
        $DinamicStatment.text            = $DinamicStatment.text + "Динамик отключен`n"
        $DinamicStatusIco.image          = ICO_Extractor (6)
        $DinamicBtn.Visible              = $true
    } elseif ((Get-AudioDevice -PlaybackVolume) -lt 50) {
        $DinamicStatment.text            = $DinamicStatment.text + "Громкость динамика снижена"
        $DinamicStatusIco.image          = ICO_Extractor (5)
        $DinamicBtn.Visible              = $true
    } else {
        $DinamicStatment.text            = "Готов к работе"
        $DinamicCheckBox.Checked         = $false
        $DinamicBtn.Visible              = $false
        $DinamicStatusIco.image          = ICO_Extractor (4)
    }

    #Check if there are separate ComunicationDevices
    if ($HeadSetName.text -eq $DinamicName.text){
        $HeadSetDinamicFlag             = $false
    }else{
        $HeadSetDinamicFlag             = $true
    }

    if ($HeadSetNameMic.text -eq $MicrophoneName.text){
        $HeadSetMicFlag                 = $false
    }else{
        $HeadSetMicFlag                 = $true
    }
    $TroubleshootingBtn.BackColor       = "#ffffff"
    $TroubleshootingBtn.ForeColor       = "#000"
    
    $Level_Label.BringToFront()
    
    Headset_Remove
}

Function Headset_Remove{
    if ($FirstStart -eq $true){
        $FirstStart                     = $false
        if ($HeadSetDinamicFlag -eq $false){
            $HeadSetName.Visible        = $false
            $HeadSetNameMic.location    = New-Object System.Drawing.Point(45,120)
        }

        if ($HeadSetMicFlag -eq $false){
            $HeadSetNameMic.Visible     = $false
        }

        if (($HeadSetDinamicFlag -eq $false) -and ($HeadSetMicFlag -eq $false)){
            $HeadSetIco.Visible         = $false
            $HeadSetLabel1.Visible      = $false
            $HeadSetStatment.Visible    = $false
            $HeadSetStatusIco.Visible   = $false
            $HeadSetLabel2.Visible      = $false
            $HeadSetVolume.Visible      = $false
            $HeadSetCheckBox.Visible    = $false
            $HeadSetBtn.Visible         = $false

            $MicrophoneName.location        = New-Object System.Drawing.Point(100,120)
            $DinamicName.location           = New-Object System.Drawing.Point(295,120)
            $MicrophoneIco.location         = New-Object System.Drawing.Point(130,50)
            $DinamicIco.location            = New-Object System.Drawing.Point(310,50)
            $MicrophoneStatusIco.location   = New-Object System.Drawing.Point(150,99)
            $DinamicStatusIco.location      = New-Object System.Drawing.Point(340,99)
                
            $MicrophoneLabel1.location      = New-Object System.Drawing.Point(20,180)
            $DinamicLabel1.location         = New-Object System.Drawing.Point(20,215)
            $MicrophoneStatment.location    = New-Object System.Drawing.Point(100,180)
            $DinamicStatment.location       = New-Object System.Drawing.Point(100,215)
                
            $NewSettings.location           = New-Object System.Drawing.Point(2,270)
            $MicrophoneLabel2.location      = New-Object System.Drawing.Point(20,315)
            $DinamicLabel2.location         = New-Object System.Drawing.Point(20,350)
            $MicrophoneVolume.location      = New-Object System.Drawing.Point(100,315)
            $DinamicVolume.location         = New-Object System.Drawing.Point(100,350)
            $MicrophoneCheckBox.location    = New-Object System.Drawing.Point(220,315)
            $DinamicCheckBox.location       = New-Object System.Drawing.Point(220,350)

            $cancelBtn.location             = New-Object System.Drawing.Point(350,410)
            $TroubleshootingBtn.location    = New-Object System.Drawing.Point(220,410)
            $MicrophoneBtn.location         = New-Object System.Drawing.Point(220,315)
            $DinamicBtn.location            = New-Object System.Drawing.Point(220,350)

            $Logo_ICO.location              = New-Object System.Drawing.Point(20,390)
            $Scale_ICO.location             = New-Object System.Drawing.Point(108,295)
            $Level_Label.location           = New-Object System.Drawing.Point(108,375)
            $Version.location               = New-Object System.Drawing.Point(5,435)
           
            $NewSettings.height             = 188
        } else {
            $MicrophoneName.location        = New-Object System.Drawing.Point(200,120)
            $DinamicName.location           = New-Object System.Drawing.Point(355,120)
            $MicrophoneIco.location         = New-Object System.Drawing.Point(220,50)
            $DinamicIco.location            = New-Object System.Drawing.Point(370,50)
            $MicrophoneStatusIco.location   = New-Object System.Drawing.Point(250,99)
            $DinamicStatusIco.location      = New-Object System.Drawing.Point(400,99)
        
            $MicrophoneLabel1.location      = New-Object System.Drawing.Point(20,215)
            $DinamicLabel1.location         = New-Object System.Drawing.Point(20,250)
            $MicrophoneStatment.location    = New-Object System.Drawing.Point(100,215)
            $DinamicStatment.location       = New-Object System.Drawing.Point(100,250)

            $NewSettings.location           = New-Object System.Drawing.Point(2,305)
            $MicrophoneLabel2.location      = New-Object System.Drawing.Point(20,385)
            $DinamicLabel2.location         = New-Object System.Drawing.Point(20,420)
            $MicrophoneVolume.location      = New-Object System.Drawing.Point(100,385)
            $DinamicVolume.location         = New-Object System.Drawing.Point(100,420)
            $MicrophoneCheckBox.location    = New-Object System.Drawing.Point(220,385)
            $DinamicCheckBox.location       = New-Object System.Drawing.Point(220,420)

            $cancelBtn.location             = New-Object System.Drawing.Point(350,480)
            $TroubleshootingBtn.location    = New-Object System.Drawing.Point(220,480)
            $MicrophoneBtn.location         = New-Object System.Drawing.Point(220,385)
            $DinamicBtn.location            = New-Object System.Drawing.Point(220,420)

            $Logo_ICO.location              = New-Object System.Drawing.Point(20,460)
            $Scale_ICO.location             = New-Object System.Drawing.Point(108,330)
            $Level_Label.location           = New-Object System.Drawing.Point(108,445)
            $Version.location               = New-Object System.Drawing.Point(5,505)

            $NewSettings.height             = 223
        }

        Colour_If_CheckBox
}
}

function Troubleshooting { 
    try {
        $TroubleshootingBtn.BackColor       = "#0032B1"
        $TroubleshootingBtn.ForeColor       = "#F1F1F1"
        
        $HeadSetVolumeSet                       = $HeadSetVolume.Value
        $RecordingVolumeSet                     = $MicrophoneVolume.Value
        $PlaybackVolumeSet                      = $DinamicVolume.Value

        Troubleshooting_HeadSet ($true)
        
    }
    catch {
        Error_General  
    }
}

function Troubleshooting_HeadSet {
    Param($Next)

    # Script to set default HeadSet volume
    if (($HeadSetCheckBox.Checked -eq $true) -and ($HeadSetMicFlag -eq $true)) {
        if ($HeadSetVolumeSet -le 1){
            Set-AudioDevice -RecordingCommunicationMute $true
        }else{
            Set-AudioDevice -RecordingCommunicationMute $false
            Set-AudioDevice -RecordingCommunicationVolume $HeadSetVolumeSet
        }
    }

    if (($HeadSetCheckBox.Checked -eq $true) -and ($HeadSetDinamicFlag -eq $true)) {
        if ($HeadSetVolumeSet -le 1){
            Set-AudioDevice -PlaybackCommunicationMute $true
        }else{
            Set-AudioDevice -PlaybackCommunicationMute $false
            Set-AudioDevice -PlaybackCommunicationVolume $HeadSetVolumeSet
        }
    }

    If ($Next -eq $true){
        Troubleshooting_Microphone ($true)
    } else {
        Devices_Status
    }
}

function Troubleshooting_Microphone {
    Param($Next)
    
    # Script to set default microphone volume
    if ($MicrophoneCheckBox.Checked -eq $true) {
        if ($RecordingVolumeSet -le 1){
            Set-AudioDevice -RecordingMute $true
        }else{
            Set-AudioDevice -RecordingMute $false
            Set-AudioDevice -RecordingVolume $RecordingVolumeSet
        }
    }

    if (($MicrophoneCheckBox.Checked -eq $true) -and ($HeadSetMicFlag -eq $false)){
        if ($RecordingVolumeSet -le 1){
            Set-AudioDevice -RecordingCommunicationMute $true
        }else{
            Set-AudioDevice -RecordingCommunicationMute $false
            Set-AudioDevice -RecordingCommunicationVolume $RecordingVolumeSet
        }
    }

    If ($Next -eq $true){
        Troubleshooting_Dinamic ($true)
    } else {
        Devices_Status
    }
}

function Troubleshooting_Dinamic {

    Param($Next)
    
    # Script to set default Speaker volume
    if ($DinamicCheckBox.Checked -eq $true) {
        if ($PlaybackVolumeSet -le 1){
            Set-AudioDevice -PlaybackMute $true
        }else{
            Set-AudioDevice -PlaybackMute $false
            Set-AudioDevice -PlaybackVolume $PlaybackVolumeSet
        }
    }

    if (($DinamicCheckBox.Checked -eq $true) -and ($HeadSetDinamicFlag -eq $false)){
        if ($PlaybackVolumeSet -le 1){
            Set-AudioDevice -PlaybackCommunicationMute $true
        }else{
            Set-AudioDevice -PlaybackCommunicationMute $false
            Set-AudioDevice -PlaybackCommunicationVolume $PlaybackVolumeSet
        }
    }

    If ($Next -eq $true){
        Troubleshooting_Dinamic
    } else {
        Devices_Status
    }
}

Function Get_Hash{
    Param($FileName)
    If ($FileName -eq "Logo_Rus.png"){
        $path                                 = "C:\Program Files\PS_Tools\OutlookSignature\"
    }elseif ($FileName -eq "AudioDeviceCmdlets.dll"){
        $path                                 = "C:\Program Files\PS_Tools\SoundCheck\AudioDeviceCmdlets\Release\"
    }else{
        $path                                 = "C:\Program Files\PS_Tools\SoundCheck\AudioDeviceCmdlets\icons\"
    }
    return Get-FileHash $path\$FileName -Algorithm SHA512 | Select-Object Hash | foreach {$_.Hash}
}

Function HASH_Error{
    write-host "`nОшибка проверки ХЭШ суммы." -ForegroundColor RED 
    Read-Host "`nPress Enter to exit"
}

#---------------------------------------------------------[Script]-----------------------------------------------------------#

try{
    #Enable running scripts on this system
    #Set-ExecutionPolicy Unrestricted -Scope CurrentUser -Force

    #Scheck Hash for AudioDeviceCmdlets.dll
    [string]$Ico_1 = "92E3F556CB11034B4427D5E7AE51059BCB86928833B3192CE6D1573DEE0CC973B7FE3830D85EFD265A4A47E01DA7B121F9D5C8E426A46A6875ACFA854F0FC834"
    [string]$Ico_2 = "C249D420CDDD3E1071878AA863DDCFA4876F561312339FFA394D46EFCFE21581BA2B8C51D18175DE69DD440727C08D78E03B41B8902F6F9F998BEF634CFE0D82"
    [string]$Ico_3 = "4A539C01C8831A24DA1294EA13810D69940C975BEA550FC8614E8C15A3C7E3218F9FE2210065BD9FFD7D3C5AB6D29BCB53C54173292B7F8333A3A9CD5573C792"
    [string]$Scale = "966C6AF227DA48FC235C56229CEEDA317F53E8552A890A514C2E3F9588C15DFE0DFCCBE36063575EA1DD7846910700C1AB1EEECFFAC6C5AF61F3A9885BE4492A"
    [string]$Logo  = "51EF4E3D0BF4B064C6C306F9103BC5CBB340719F63B709A79DF6E406621D419658596A790C40EBDDCDC0588E057AA3ADD34877FA839E36714B464EF0D485E50E"
    [string]$DLL   = "706FF2A96BE8E25FB6021A3DABC2D95A3FAF8BE4D60F6628260C12442E33BD1E675C6A6A6BCA098CC1745249011D69B8C095DF3DD95F27F622AF4027252E89A7"

    if ($Ico_1 -ne [string](Get_Hash("1.ico"))){
        HASH_Error
    } elseif ($Ico_2 -ne [string](Get_Hash("2.ico"))) {
        HASH_Error
    } elseif ($Ico_3 -ne [string](Get_Hash("3.ico"))) {
       HASH_Error
    } elseif ($Scale -ne [string](Get_Hash("Scale.png"))) {
       HASH_Error
    } elseif ($Logo -ne [string](Get_Hash("Logo_Rus.png"))) {
       HASH_Error
    } elseif ($DLL -ne [string](Get_Hash("AudioDeviceCmdlets.dll"))) {
       HASH_Error
    } else {

        # Import module AudioDeviceCmdlets
        #$FilePath = "C:\Program Files\PS_Tools\SoundCheck\AudioDeviceCmdlets\Release\AudioDeviceCmdlets.dll"
        #New-Item "$($profile | split-path)\Modules\AudioDeviceCmdlets" -Type directory -Force
        #Copy-Item $FilePath "$($profile | split-path)\Modules\AudioDeviceCmdlets\AudioDeviceCmdlets.dll"
        #Set-Location "$($profile | Split-Path)\Modules\AudioDeviceCmdlets"
        
        #Set-Location "C:\Program Files\PS_Tools\SoundCheck\AudioDeviceCmdlets\Release\"
        #Get-ChildItem | Unblock-File
        
        Import-Module AudioDeviceCmdlets 

        #Set volume for Speaker and Microphone
        $HeadSetVolumeSet   = 60
        $RecordingVolumeSet = 60
        $PlaybackVolumeSet  = 50	

        #Start main window
        $FirstStart         = $true
        Main_Window
        PowerShell.exe -ExecutionPolicy Unrestricted -WindowStyle Hidden { "C:\Program Files\PS_Tools\SoundCheck\SoundCheck_Gui.ps1" }
        [void]$ITMultiToolForm.ShowDialog()
    }

} catch {
    Error_General
}